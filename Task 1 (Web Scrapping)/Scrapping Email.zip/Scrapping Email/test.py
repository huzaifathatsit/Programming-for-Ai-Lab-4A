import sys
sys.path.insert(0, '.')
from app import app
print('App imported successfully')